#!/bin/bash
CLIENT=$1
pivpn -qr $CLIENT
